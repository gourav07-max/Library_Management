package com.example.UserBook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
